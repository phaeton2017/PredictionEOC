import numpy as np
import lightgbm as lgb
from sklearn.model_selection import train_test_split
import pandas as pd

df = pd.read_csv('训练集评分系统.csv')
df.dropna(inplace=True)
which = ['pred', 'X19T1']

X_train = df[which].values
y_train = df[['PFS_real']].values
PFS_e_train = df[['PFS_e']].values

df_test = pd.read_csv('测试集评分系统.csv')
X_test = df_test[which].values


def cox_partial_likelihood(preds, dataset):
    # 提取数据
    labels = dataset.get_label()
    events = dataset.get_field('events')

    exp_preds = np.exp(preds)

    risk_set = np.cumsum(exp_preds[::-1])[::-1]

    partial_likelihood = -np.sum((preds - np.log(risk_set)) * events)

    grad = events - (exp_preds / risk_set)
    hess = -exp_preds * (risk_set - exp_preds) / (risk_set ** 2)

    return partial_likelihood, grad, hess

train_data = lgb.Dataset(X_train, label=y_train)
print(train_data.data)
train_data.set_field('events', PFS_e_train)

params = {
    'objective': 'cox',
    'metric': 'None'
}

gbm = lgb.train(params, train_data, num_boost_round=100, fobj=cox_partial_likelihood)

preds = gbm.predict(X_test)