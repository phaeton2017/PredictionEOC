from pytorch_pretrained_vit import ViT
import numpy as np
import torch
import torch.nn as nn
import pandas as pd
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import random
from dataset.ovarian_dataset import Dataset_name, Dataset_with_randomcrop
from tools.tools import neg_par_log_likelihood, c_index
from models.vit_model import Your_model
from models.resnet50 import resnet_50, resnet_18
from models.resnext_29 import ResNeXt29_32x4d, ResNeXt29_8x64d, ResNeXt29_4x64d, ResNeXt29_2x64d
from torchvision.models import DenseNet
import torch.backends.cudnn as cudnn
from lifelines.utils import concordance_index
import time


# seed = 0
# np.random.seed(seed)
# torch.manual_seed(seed)
# torch.cuda.manual_seed(seed)
# cudnn.deterministic = True
# cudnn.benchmark = False


class argparse:
    pass


def exclude_second_school(dataframe, exclude_dataframe):
    test_df = exclude_dataframe[['head', 'PFS_real', 'PFS_e']]
    second_school = test_df['head'].to_list()
    not_in_list = ~dataframe['head'].isin(second_school)
    dataframe = dataframe[not_in_list][['head', 'PFS_real', 'PFS_e']]

    return dataframe


if __name__ == "__main__":
    print("GPU", torch.cuda.is_available())

    for seed in range(100):
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed(seed)
        cudnn.deterministic = True
        cudnn.benchmark = False

        args = argparse()
        args.epochs, args.learning_rate, args.interval = [40, 0.001, 1]
        args.outline, args.per = [5, 0]
        args.device, = [torch.device("cuda:0" if torch.cuda.is_available() else "cpu"), ]

        # label_df = pd.read_csv('./csv/ovarian_500_data_V2.csv')[['head', 'PFS_real', 'PFS_e']]
        test_df = pd.read_csv('./csv/people_28/external_test.csv')[['head', 'PFS_real', 'PFS_e']]
        # label_df.dropna(inplace=True)
        # train_df, valid_df = train_test_split(label_df, test_size=0.2, random_state=1)
        # # train_df.to_csv('./csv/train_df_0.2_max.csv')
        # # valid_df.to_csv('./csv/test_df_0.2_max.csv')

        train_df = pd.read_csv('./csv/people_28/train_df_with_external_test_28.csv')[['head', 'PFS_real', 'PFS_e']]
        valid_df = pd.read_csv('./csv/people_28/valid_df_with_external_test_28.csv')[['head', 'PFS_real', 'PFS_e']]

        # train_df = exclude_second_school(train_df, test_df)
        # valid_df = exclude_second_school(valid_df, test_df)

        # train_df.to_csv('./csv/people_28/train_df_with_external_test_28.csv')
        # valid_df.to_csv('./csv/people_28/valid_df_with_external_test_28.csv')
        # test_df.to_csv('./external_test.csv')

        # train_df.info()
        # valid_df.info()

        # , args.outline, args.per
        tranin_dataset = Dataset_name(train_df, './ovarian_500_max_slice', args.outline, args.per, flag='train')
        valid_dataset = Dataset_name(valid_df, './ovarian_500_max_slice', args.outline, args.per, flag='valid')
        test_dataset = Dataset_name(test_df, './ovarian_500_max_slice', args.outline, args.per, flag='test')
        # print(len(tranin_dataset))
        # print(len(valid_dataset))
        train_dataloader = DataLoader(dataset=tranin_dataset, batch_size=32, shuffle=True, drop_last=True)
        valid_dataloader = DataLoader(dataset=valid_dataset, batch_size=len(valid_dataset), shuffle=True,
                                      drop_last=True)
        test_dataloader = DataLoader(dataset=test_dataset, batch_size=len(test_dataset), shuffle=True,
                                     drop_last=True)

        # model_name = 'densenet_roi'
        model = resnet_18()
        # model = ResNeXt29_32x4d()
        # model = DenseNet(num_classes=1)
        # model = Your_model()
        # state_dict = torch.load('./model_parameter/transformer_2_result_param.pth')
        # model.load_state_dict(state_dict)
        model = model.to(args.device)
        criterion = torch.nn.MSELoss()
        # optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate)
        optimizer = torch.optim.SGD(model.parameters(), lr=args.learning_rate, weight_decay=5e-3)
        # scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=args.epochs // 10, gamma=0.9)

        train_loss = []
        valid_loss = []
        train_epochs_loss = []
        valid_epochs_loss = []
        tra_cin_epochs = []
        val_cin_epochs = []

        max_internal_test_cin = 0

        test_cin_epochs = []

        summaryWriter = SummaryWriter("logs/log1")

        for epoch in range(args.epochs):

            model.train()
            train_epoch_loss = []
            train_cin_index_list = []
            t0 = time.time()
            for idx, data in enumerate(train_dataloader):
                # print(type(data[0]))
                img = data[0].to(torch.float32).to(args.device)
                pfs = data[1].to(torch.float32).to(args.device)
                pfs_e = data[2].to(torch.float32).to(args.device)

                outputs = model(img).squeeze()
                # print('output', outputs.size())
                # print('pfs', pfs.size())
                # print('e', pfs_e.size())

                train_cindex = concordance_index(pfs.cpu().detach().numpy(), -outputs.cpu().detach().numpy(),
                                                 pfs_e.cpu().detach().numpy())
                train_cin_index_list.append(train_cindex)

                # print(outputs.size())
                optimizer.zero_grad()

                sorted_indices = torch.argsort(pfs, descending=True)
                outputs = outputs[sorted_indices]
                pfs = pfs[sorted_indices]
                pfs_e = pfs_e[sorted_indices]

                loss = neg_par_log_likelihood(outputs, pfs, pfs_e)

                if not torch.isnan(loss).any():
                    loss.backward()
                    optimizer.step()
                    train_epoch_loss.append(loss.item())
                    train_loss.append(loss.item())
                    # if idx % (len(train_dataloader) // 2) == 0:
                    #     print("output:{},pfs:{},pfs_e:{},loss:{}".format(outputs, pfs, pfs_e, loss))
                    #     print("epoch={}/{},{}/{}of train, loss={}, c_index={}".format(
                    #         epoch, args.epochs, idx, len(train_dataloader), loss.item(), train_cindex))

            tra_cin_epochs.append(np.average(train_cin_index_list))
            train_epochs_loss.append(np.average(train_epoch_loss))
            # scheduler.step()

            t1 = time.time()
            training_time = (t1 - t0) * 1000
            # print(f'训练时间 {training_time:.2f} ms')

            # =====================valid============================
            if epoch % args.interval == 0:
                # if True:
                model.eval()
                with torch.no_grad():
                    valid_epoch_loss = []
                    val_cin_index_list = []

                    for idx, data in enumerate(valid_dataloader):
                        img = data[0].to(torch.float32).to(args.device)
                        pfs = data[1].to(torch.float32).to(args.device)
                        pfs_e = data[2].to(torch.float32).to(args.device)

                        outputs = model(img).squeeze()

                        eval_cindex = concordance_index(pfs.cpu().detach().numpy(), -outputs.cpu().detach().numpy(),
                                                        pfs_e.cpu().detach().numpy())

                        if eval_cindex > max_internal_test_cin:
                            max_internal_test_cin = eval_cindex
                            # torch.save(model.state_dict(),
                            #            './model_parameter/people_28/densenet_roi/%s' % model_name + '_601_seed_%d.pth' % seed)

                        val_cin_index_list.append(eval_cindex)

                        sorted_indices = torch.argsort(pfs, descending=True)
                        outputs = outputs[sorted_indices]
                        pfs = pfs[sorted_indices]
                        pfs_e = pfs_e[sorted_indices]

                        loss = neg_par_log_likelihood(outputs, pfs, pfs_e)

                        if not torch.isnan(loss).any():
                            valid_epoch_loss.append(loss.item())
                            valid_loss.append(loss.item())

                    for idx, data in enumerate(test_dataloader):
                        img = data[0].to(torch.float32).to(args.device)
                        pfs = data[1].to(torch.float32).to(args.device)
                        pfs_e = data[2].to(torch.float32).to(args.device)

                        outputs = model(img).squeeze()

                        test_cindex = concordance_index(pfs.cpu().detach().numpy(), -outputs.cpu().detach().numpy(),
                                                        pfs_e.cpu().detach().numpy())
                        test_cin_epochs.append(test_cindex)

                    val_cin_epochs.append(np.average(val_cin_index_list))
                    valid_epochs_loss.append(np.average(valid_epoch_loss))
                # ====================adjust lr========================
                # lr_adjust = {
                #     2: 5e-5, 4: 1e-5, 6: 5e-6, 8: 1e-6,
                #     10: 5e-7, 15: 1e-7, 20: 5e-8
                # }
            # if epoch > 30:
            #     args.learning_rate = args.learning_rate/2
            #     for param_group in optimizer.param_groups:
            #         param_group['lr'] = args.learning_rate
            #     print('Updating learning rate to {}'.format(args.learning_rate))

            # if val_cin_epochs[-1] > 0.6:
            # torch.save(model.state_dict(), './model_parameter/resnet18_test_v2.pth')

            summaryWriter.add_scalar("loss_train", train_epochs_loss[-1], epoch)
            summaryWriter.add_scalar("loss_valid", valid_epochs_loss[-1], epoch)
            summaryWriter.add_scalar("cin_train", tra_cin_epochs[-1], epoch)
            summaryWriter.add_scalar("cin_valid", val_cin_epochs[-1], epoch)

        x_values = [x * args.interval for x in range(len(val_cin_epochs))]
        plt.figure(figsize=(12, 4))
        plt.subplot(121)
        plt.plot(tra_cin_epochs, '-o', label="train_cin")
        plt.plot(x_values, val_cin_epochs, '-o', label="valid_cin")
        plt.title("C_index")
        plt.subplot(122)
        plt.plot(train_epochs_loss, '-o', label="train_loss")
        plt.plot(x_values, valid_epochs_loss, '-o', label="valid_loss")
        plt.title("epochs_loss")
        plt.legend()
        plt.show()

        print(val_cin_epochs.index(max(val_cin_epochs)))
        print(tra_cin_epochs[val_cin_epochs.index(max(val_cin_epochs))])
        print(max(val_cin_epochs))
        print(test_cin_epochs[val_cin_epochs.index(max(val_cin_epochs))])
        # print('数据种子', data_seed)
        print('种子', seed)
        # torch.save(model.state_dict(), './model_parameter/people_28/resnet_randomcrop_527_seed_%d.pth'%(seed))
