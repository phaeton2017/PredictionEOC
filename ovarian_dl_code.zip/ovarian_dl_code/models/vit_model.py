from pytorch_pretrained_vit import ViT
import torch.nn as nn


class Your_model(nn.Module):
    def __init__(self):
        super(Your_model, self).__init__()
        vit = ViT('B_16',
                  pretrained=False,
                  patches=16,
                  dim=16,
                  ff_dim=64,
                  num_heads=4,
                  num_layers=4,
                  in_channels=3,
                  image_size=224)
        vit.fc = nn.Linear(768, 1, bias=True)
        self.vit = vit
        # self.fc1 = nn.Linear(768, 768, bias=False)
        # self.fc2 = nn.Linear(768, 1, bias=False)
        # self.tanh = nn.Tanh()

        # for name, parameter in self.vit.named_parameters():
        #     if name == 'fc.weight' or name == 'fc.bias':
        #         parameter.requires_grad = True
        #     else:
        #         parameter.requires_grad = False

    def forward(self, x):
        x = self.vit(x)
        # x = self.tanh(x)
        # x = self.fc1(x)
        # x = self.fc2(x)
        return x

if __name__ == "__main__":
    import torch
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = Your_model().to(device)
    # input = torch.randn((1, 3, 512, 512))
    # output = model(input)
    # from torchsummary import summary
    # summary(model, input_size=(3, 224, 224))
    # print(output.shape)

    # from torchstat import stat
    #
    # stat(model.cpu(), (3, 224, 224))

    inputs = torch.randn(1, 3, 224, 224).to(device)

    from thop import profile
    flops, params = profile(model, inputs=(inputs, ))
    print(flops)
    print(params)