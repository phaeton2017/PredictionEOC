import torch
import torchvision.models as models
import torch.nn as nn


class resnet_50(nn.Module):
    def __init__(self):
        super(resnet_50, self).__init__()
        self.resnet50 = models.resnet50(pretrained=False)
        self.resnet50.fc = nn.Linear(2048, 1, bias=True)

    def forward(self, x):
        x = self.resnet50(x)
        return x


class resnet_18(nn.Module):
    def __init__(self):
        super(resnet_18, self).__init__()
        self.resnet18 = models.resnet18(pretrained=False)
        self.resnet18.fc = nn.Linear(512, 1, bias=True)

    def forward(self, x):
        x = self.resnet18(x)
        return x


if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = resnet_50().to(device)
    # input = torch.randn((1, 3, 512, 512))
    # output = model(input)
    # from torchsummary import summary
    # summary(model, input_size=(3, 224, 224))
    # print(output.shape)

    inputs = torch.randn(1, 3, 224, 224).to(device)

    from thop import profile

    flops, params = profile(model, inputs=(inputs,))
    print(flops)
    print(params)
