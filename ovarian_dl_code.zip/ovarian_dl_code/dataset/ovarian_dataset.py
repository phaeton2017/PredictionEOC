import numpy as np
from torch.utils.data import Dataset
import os
import re
import cv2
from PIL import Image
from einops import rearrange
from natsort import natsorted
import torchvision.transforms as transform
import matplotlib.pyplot as plt


def adjust_coordinates(x1, y1, x2, y2):
    # 计算原矩形的长和宽
    width = abs(x2 - x1)
    height = abs(y2 - y1)

    # 找到原矩形的中心坐标
    center_x = (x1 + x2) // 2
    center_y = (y1 + y2) // 2

    # 计算新矩形的左上角和右下角坐标
    new_x1 = center_x - max(width, height) // 2
    new_y1 = center_y - max(width, height) // 2
    new_x2 = center_x + max(width, height) // 2
    new_y2 = center_y + max(width, height) // 2

    # 确保新矩形的坐标范围在 0 到 511 之间
    new_x1 = max(0, min(new_x1, 511))
    new_y1 = max(0, min(new_y1, 511))
    new_x2 = max(0, min(new_x2, 511))
    new_y2 = max(0, min(new_y2, 511))

    return new_x1, new_y1, new_x2, new_y2


def roi_extractor(X, m, img_size=224, outline=5, perturbation=0.5):

    CT = X

    x, y = np.where(m > 0)
    if perturbation != 0:
        outline1 = outline + np.random.randint(0, +perturbation * outline)
        outline2 = outline + np.random.randint(0, +perturbation * outline)
        outline3 = outline + np.random.randint(0, +perturbation * outline)
        outline4 = outline + np.random.randint(0, +perturbation * outline)
    else:
        outline1 = outline
        outline2 = outline
        outline3 = outline
        outline4 = outline

    w0, h0 = m.shape
    x_min = max(0, int(np.min(x) - outline1))
    x_max = min(w0, int(np.max(x) + outline2))
    y_min = max(0, int(np.min(y) - outline3))
    y_max = min(h0, int(np.max(y) + outline4))


    # if x_max - x_min != y_max - y_min:
    #     x_min, y_min, x_max, y_max = adjust_coordinates(x_min, y_min, x_max, y_max)

    # m = m[x_min:x_max, y_min:y_max]
    X = X[x_min:x_max, y_min:y_max]

    X_m_1 = X.copy()
    # print(X_m_1.shape)

    # assert X_m_1.shape[0] == X_m_1.shape[1]

    if X_m_1.shape[0] != img_size or X_m_1.shape[1] != img_size:
        X_m_1 = cv2.resize(X_m_1, (img_size, img_size), interpolation=cv2.INTER_CUBIC)
        CT = cv2.resize(CT, (img_size, img_size), interpolation=cv2.INTER_CUBIC)
        m = cv2.resize(m, (img_size, img_size), interpolation=cv2.INTER_CUBIC)

    # print(X_m_1.shape)

    # X_m_1 = (X_m_1 - np.min(X_m_1)) / (np.max(X_m_1) - np.min(X_m_1))

    X_m_1 = np.expand_dims(X_m_1, axis=-1)
    CT = np.expand_dims(CT, axis=-1)
    m = np.expand_dims(m, axis=-1)

    X_m_1 = np.concatenate([CT, CT, CT], axis=-1)

    X_m_1 = rearrange(X_m_1, 'h w c -> c h w')
    return X_m_1


class Dataset_name(Dataset):
    def __init__(self, dataframe, img_path, outline=5, perturbation_ratio=0, flag='train'):
        assert flag in ['train', 'test', 'valid']
        self.flag = flag
        self.img_path = img_path
        self.outline = outline
        if flag == 'train':
            self.perturbation_ratio = perturbation_ratio
        else:
            self.perturbation_ratio = 0
        # 图片和mask存放路径
        self.img_list = []
        self.mask_list = []
        self.pfs = []
        self.pfs_e = []
        self.name = []
        self.__load_data__(dataframe)

    def __getitem__(self, index):
        # return roi_extractor(self.img_list[index], self.mask_list[index], 224, self.outline,
        #                      perturbation=self.perturbation_ratio), \
        #     self.pfs[index], self.pfs_e[index], \
        #     self.name[index]
        # -----------------------------------------------------------------------------
        return self.img_list[index], self.pfs[index], self.pfs_e[index], self.name[index]

    def __len__(self):
        return len(self.img_list)

    def __load_data__(self, dataframes):
        name_pfs = dataframes
        # -----------------------------------------------------------------------------
        # column_data = name_pfs['PFS_real'].tolist()
        # trans_data, lamba = stats.boxcox(column_data)
        #
        # mean = np.mean(trans_data)
        # std = np.std(trans_data)
        # arr = []
        # for x in trans_data:
        #     arr.append((x - mean) / std)
        #
        # name_pfs['PFS_real'] = arr
        # -----------------------------------------------------------------------------

        for index, row in name_pfs.iterrows():  # 何人检查
            checks = os.listdir(self.img_path + '/image/' + row['head'])
            checks = natsorted(checks)
            for i, check in enumerate(checks):  # 检查轮次
                if i == 0:
                    check_path = self.img_path + '/image/' + row['head'] + '/' + check
                    ori_dir = check_path + '/' + os.listdir(check_path)[0]
                    mask_dir = re.sub(r'image', 'mask', check_path + '/' + os.listdir(check_path)[0])
                    contents_ori = os.listdir(ori_dir)
                    contents_mask = os.listdir(mask_dir)
                    # print("开始", row['head'])
                    # print(contents_ori)
                    # print(contents_mask)
                    assert len(contents_ori) == len(contents_mask)  # 每张源图像都应该与一张mask相对应
                    for content in contents_ori:
                        target_prefix = content[:-4]
                        # 使用列表解析来匹配包含相同前缀的字符串
                        matching_strings = [s for s in contents_mask if s.startswith(target_prefix)]
                        assert len(matching_strings) == 1

                        # image1 = Image.open(os.path.join(ori_dir, content))
                        # image2 = Image.open(os.path.join(mask_dir, matching_strings[0]))
                        # X = np.array(image1, np.float32)
                        # m = np.array(image2, np.float32)
                        # self.img_list.append(roi_extractor(X, m))
                        # 内存炸了
                        # ----------------------------------------------------------------
                        image1 = Image.open(os.path.join(ori_dir, content))
                        image2 = Image.open(os.path.join(mask_dir, matching_strings[0]))
                        X = np.array(image1, np.float32)

                        X = np.uint8(cv2.normalize(X, None, 0, 255, cv2.NORM_MINMAX))
                        X = X[:, :, 0]
                        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
                        X = clahe.apply(X)
                        X = (X - np.min(X)) / (np.max(X) - np.min(X))

                        m = np.array(image2, np.float32)

                        self.img_list.append(roi_extractor(X, m))

                        # self.img_list.append(X)
                        # self.mask_list.append(m)

                        self.pfs.append(row['PFS_real'])
                        self.pfs_e.append(row['PFS_e'])
                        self.name.append(row['head'])

            # print("完成", row['head'])


def roi_extractor_with_randomcrop(X):
    X = np.uint8(cv2.normalize(X, None, 0, 255, cv2.NORM_MINMAX))
    X = X[:, :, 0]

    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    X = clahe.apply(X)
    X = (X - np.min(X)) / (np.max(X) - np.min(X))

    X_m_1 = X.copy()

    X_m_1 = np.expand_dims(X_m_1, axis=-1)

    X_m_1 = np.concatenate([X_m_1, X_m_1, X_m_1], axis=-1)

    X_m_1 = rearrange(X_m_1, 'h w c -> c h w')
    return X_m_1


class Dataset_with_randomcrop(Dataset):
    def __init__(self, dataframe, img_path, flag='train'):
        assert flag in ['train', 'test', 'valid']
        self.flag = flag
        self.img_path = img_path
        if flag == 'train':
            self.transform = transform.Compose([
                transform.RandomCrop(400),
                transform.Resize(224, )
            ])
        else:
            self.transform = transform.Compose([
                transform.Resize(224, )
            ])

        # 图片和mask存放路径
        self.img_list = []
        self.mask_list = []
        self.pfs = []
        self.pfs_e = []
        self.name = []
        self.__load_data__(dataframe)

    def __getitem__(self, index):
        image = Image.open(self.img_list[index])
        image = self.transform(image)
        # mask = Image.open(self.mask_list[index])
        image = np.array(image, np.float32)

        # mask = np.array(mask)
        return roi_extractor_with_randomcrop(image), self.pfs[index], self.pfs_e[index]
        # -----------------------------------------------------------------------------
        # return self.img_list[index], self.pfs[index], self.pfs_e[index], self.name[index]

    def __len__(self):
        return len(self.img_list)

    def __load_data__(self, dataframes):
        name_pfs = dataframes

        for index, row in name_pfs.iterrows():  # 何人检查
            checks = os.listdir(self.img_path + '/image/' + row['head'])
            checks = natsorted(checks)
            for i, check in enumerate(checks):  # 检查轮次
                if i == 0:
                    check_path = self.img_path + '/image/' + row['head'] + '/' + check
                    ori_dir = check_path + '/' + os.listdir(check_path)[0]
                    mask_dir = re.sub(r'image', 'mask', check_path + '/' + os.listdir(check_path)[0])
                    contents_ori = os.listdir(ori_dir)
                    contents_mask = os.listdir(mask_dir)
                    # print("开始", row['head'])
                    # print(contents_ori)
                    # print(contents_mask)
                    assert len(contents_ori) == len(contents_mask)  # 每张源图像都应该与一张mask相对应
                    for content in contents_ori:
                        target_prefix = content[:-4]
                        # 使用列表解析来匹配包含相同前缀的字符串
                        matching_strings = [s for s in contents_mask if s.startswith(target_prefix)]
                        assert len(matching_strings) == 1

                        # image1 = Image.open(os.path.join(ori_dir, content))
                        # image2 = Image.open(os.path.join(mask_dir, matching_strings[0]))
                        # X = np.array(image1, np.float32)
                        # m = np.array(image2, np.float32)
                        # self.img_list.append(roi_extractor(X, m))
                        # 内存炸了
                        # ----------------------------------------------------------------
                        self.img_list.append(os.path.join(ori_dir, content))
                        self.mask_list.append(os.path.join(mask_dir, matching_strings[0]))

                        self.pfs.append(row['PFS_real'])
                        self.pfs_e.append(row['PFS_e'])
                        self.name.append(row['head'])

            # print("完成", row['head'])


if __name__ == "__main__":
    import pandas as pd

    test_df = pd.read_csv('/home/xk1/zhuzhou/code/mri_vit/csv/ovarian_500_data.csv')[['head', 'PFS_real', 'PFS_e']]
    test_dataset = Dataset_name(test_df, '/home/xk1/zhuzhou/code/mri_vit/ovarian_500')

    # x1, y1, x2, y2 = 100, 120, 250, 300
    # adjusted_coordinates = adjust_coordinates(x1, y1, x2, y2)
    #
    # print("原坐标:", (x1, y1, x2, y2))
    # print("调整后的坐标:", adjusted_coordinates)
