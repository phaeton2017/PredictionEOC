import torch

def R_set(x):
    '''Create an indicator matrix of risk sets, where T_j >= T_i.
	Note that the input data have been sorted in descending order.
	Input:
		x: a PyTorch tensor that the number of rows is equal to the number of samples.
	Output:
		indicator_matrix: an indicator matrix (which is a lower traiangular portions of matrix).
	'''
    n_sample = x.size(0)
    matrix_ones = torch.ones(n_sample, n_sample)
    indicator_matrix = torch.tril(matrix_ones)

    return (indicator_matrix)


def neg_par_log_likelihood(pred, ytime, yevent):  # event=0,censored
    # ytime should be sorted with increasing order
    '''Calculate the average Cox negative partial log-likelihood.
	Input:
		pred: linear predictors from trained model.
		ytime: true survival time from load_data().
		yevent: true censoring status from load_data().
	Output:
		cost: the cost that is to be minimized.
	'''
    n_observed = yevent.sum(0)
    ytime_indicator = R_set(ytime)
    ###if gpu is being used
    if torch.cuda.is_available():
        ytime_indicator = ytime_indicator.cuda()
    ###
    # print(ytime_indicator)
    # print(torch.exp(pred).unsqueeze(1))
    risk_set_sum = ytime_indicator.mm(torch.exp(pred).unsqueeze(1))
    # print(risk_set_sum.size())
    # print(risk_set_sum)
    diff = pred.unsqueeze(1) - torch.log(risk_set_sum)
    # print(diff.size())
    # print(diff)
    # print(yevent)
    # print(yevent.size())
    sum_diff_in_observed = torch.transpose(diff, 0, 1).mm(yevent.unsqueeze(1))
    # print(sum_diff_in_observed)
    # print(sum_diff_in_observed.size())
    cost = (- (sum_diff_in_observed / n_observed)).reshape((-1,))

    return cost


def c_index(pred, ytime, yevent):
    '''Calculate concordance index to evaluate models.
    Input:
        pred: linear predictors from trained model.
        ytime: true survival time from load_data().
        yevent: true censoring status from load_data().
    Output:
        concordance_index: c-index (between 0 and 1).
    '''
    n_sample = len(ytime)
    ytime_indicator = R_set(ytime)
    ytime_matrix = ytime_indicator - torch.diag(torch.diag(ytime_indicator))
    ###T_i is uncensored
    censor_idx = (yevent == 0).nonzero()
    zeros = torch.zeros(n_sample)
    ytime_matrix[censor_idx, :] = zeros
    ###1 if pred_i < pred_j; 0.5 if pred_i = pred_j
    pred_matrix = torch.zeros_like(ytime_matrix)
    for j in range(n_sample):
        for i in range(n_sample):
            if pred[i] < pred[j]:
                pred_matrix[j, i] = 1
            elif pred[i] == pred[j]:
                pred_matrix[j, i] = 0.5

    concord_matrix = pred_matrix.mul(ytime_matrix)
    ###numerator
    concord = torch.sum(concord_matrix)
    ###denominator
    epsilon = torch.sum(ytime_matrix)
    ###c-index = numerator/denominator
    concordance_index = torch.div(concord, epsilon)
    ###if gpu is being used
    if torch.cuda.is_available():
        concordance_index = concordance_index.cuda()
    ###
    return concordance_index


def c_index_V2(pred_scores, true_labels, event_indicators):
    """
    计算一致性指数（Concordance Index）的函数

    参数:
    - pred_scores: 模型预测的风险得分（预测分数）
    - true_labels: 真实的生存时间
    - event_indicators: 事件指示器，表示是否发生了事件（1表示发生了事件，0表示未发生事件）

    返回:
    - cindex: 一致性指数
    """
    n = len(pred_scores)
    concordant = 0
    discordant = 0
    ties = 0

    for i in range(n):
        for j in range(i + 1, n):
            if event_indicators[i] == 1 and event_indicators[j] == 1:
                # 如果两个样本都发生了事件
                if true_labels[i] < true_labels[j]:
                    concordant += 1
                elif true_labels[i] > true_labels[j]:
                    discordant += 1
                else:
                    ties += 1
            elif event_indicators[i] == 0 and event_indicators[j] == 0:
                # 如果两个样本都未发生事件，则跳过
                continue
            else:
                # 一个样本发生了事件，另一个未发生事件
                if event_indicators[i] == 1 and true_labels[i] < true_labels[j]:
                    concordant += 1
                elif event_indicators[j] == 1 and true_labels[j] < true_labels[i]:
                    concordant += 1
                elif true_labels[i] == true_labels[j]:
                    ties += 1
                else:
                    discordant += 1

    # 计算一致性指数
    cindex = (concordant + 0.5 * ties) / (concordant + discordant + ties)
    return cindex


if __name__ == "__main__":

    # 示例用法
    # 假设有模型的预测分数、真实生存时间和事件指示器
    import numpy as np
    from lifelines.utils import concordance_index
    pred_scores = np.array([0.4, 0.8, 0.6, 1.2, 0.9])
    true_labels = np.array([10, 8, 6, 12, 9])
    event_indicators = np.array([1, 1, 0, 1, 0])

    # # 计算一致性指数
    # cindex_value = c_index_V2(pred_scores, true_labels, event_indicators)
    cindex_value = concordance_index(true_labels, -pred_scores, event_indicators)
    print("Concordance Index:", cindex_value)