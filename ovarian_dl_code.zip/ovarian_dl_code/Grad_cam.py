import cv2
import os
import numpy as np
import torch
import torchvision.transforms as transforms
import json
from models.resnet50 import resnet_50, resnet_18
import pandas as pd
from dataset.ovarian_dataset import Dataset_name
from einops import rearrange
from torchvision.models import DenseNet


# 图片预处理
def img_preprocess(img_in):
    transform = transforms.Compose([
        transforms.ToTensor(),
    ])
    img_in = transform(img_in)
    img_in = img_in.to(torch.float32).unsqueeze(0)  # 3
    return img_in


# 定义获取梯度的函数
def backward_hook(module, grad_in, grad_out):
    print(grad_out[0].size())
    grad_block.append(grad_out[0].detach())


# 定义获取特征图的函数
def farward_hook(module, input, output):
    fmap_block.append(output)


# 计算grad-cam并可视化
def cam_show_img(img, feature_map, grads, out_dir, name):
    H, W, _ = img.shape
    cam = np.zeros(feature_map.shape[1:], dtype=np.float32)  # 4
    grads = grads.reshape([grads.shape[0], -1])  # 5
    print('grades', grads.shape)
    weights = np.mean(grads, axis=1)  # 6
    for i, w in enumerate(weights):
        cam += w * feature_map[i, :, :]  # 7
    # print('cam', cam)
    cam = np.maximum(cam, 0)
    # print('cam', cam)
    cam = cam / cam.max()

    # cam[:3, :] = 0
    # cam[-3:, :] = 0
    #
    # cam[:, :2] = 0
    # cam[:, -2:] = 0

    cam = cv2.resize(cam, (W, H))

    heatmap = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    cam_img = 0.3 * heatmap + 0.7 * img

    path_cam_img = os.path.join(out_dir, "%s.jpg" % name)
    cv2.imwrite(path_cam_img, cam_img)


if __name__ == '__main__':
    # path_img = './cam/bicyclxue.jpg'
    # json_path = './cam/labels.json'

    valid_df = pd.read_csv('./csv/people_28/valid_df_with_external_test_28.csv')[['head', 'PFS_real', 'PFS_e']]
    valid_dataset = Dataset_name(valid_df, './ovarian_500_max_slice')

    params_path = './model_parameter/people_28/densenet_roi'
    params = os.listdir(params_path)
    for idx, param in enumerate(params):
        path = os.path.join(params_path, param)

        for i in range(len(valid_dataset)):
            # for i in range(1):
            img, _, _, name = valid_dataset[i]
            img = rearrange(img, 'c h w -> h w c')

            # print(img.shape)

            # 存放梯度和特征图
            fmap_block = list()
            grad_block = list()

            # 图片读取；网络加载
            # img = cv2.imread(path_img, 1)
            img_input = img_preprocess(img)

            net = DenseNet(num_classes=1)
            state_dict = torch.load(path)
            net.load_state_dict(state_dict)

            output_dir = './cam/densenet_roi_v2/%d' % idx
            if not os.path.exists(output_dir):
                os.makedirs(output_dir)

            net.eval()  # 8
            print(net)
            # print(net.resnet18.layer4[-1].conv2)

            # layer = net.resnet18.layer4[-1].conv2
            # layer = net.resnet18.fc
            layer = net.features.denseblock1.denselayer3.conv2
            # layer = net.features.conv0

            # 注册hook
            layer.register_forward_hook(farward_hook)  # 9
            layer.register_backward_hook(backward_hook)

            # forward
            # print(img_input.size())
            output = net(img_input)
            # idx = np.argmax(output.cpu().data.numpy())
            # print("predict: {}".format(classes[idx]))

            # backward
            net.zero_grad()
            # class_loss = output[0, idx]
            output.backward()

            # 生成cam
            grads_val = grad_block[0].cpu().data.numpy().squeeze()
            fmap = fmap_block[0].cpu().data.numpy().squeeze()

            # 保存cam图片
            cam_show_img(img * 255, fmap, grads_val, output_dir, name)
